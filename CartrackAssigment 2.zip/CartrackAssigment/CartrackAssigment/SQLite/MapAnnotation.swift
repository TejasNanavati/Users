//
//  LoginUserDetail.swift
//  CartrackAssigment
//
//  Created by Tejas Nanavati on 08/11/22.
//
//
struct MapAnnotationModel {
    let name : String
    let email: String
    let latitude: Double
    let longitude: Double
}

